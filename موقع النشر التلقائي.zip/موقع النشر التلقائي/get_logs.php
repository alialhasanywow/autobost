<?php
if (file_exists('bot_logs.log')) {
    $logs = file_get_contents('bot_logs.log');
    echo nl2br(htmlspecialchars($logs));
} else {
    echo "لا يوجد سجل تشغيل متاح.";
}
?>