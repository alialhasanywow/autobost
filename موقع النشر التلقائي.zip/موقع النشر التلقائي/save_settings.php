<?php
header('Content-Type: application/json');

$settings = [];
if (file_exists('settings.json')) {
    $settings = json_decode(file_get_contents('settings.json'), true);
}

$settings['reply_tracking'] = $settings['reply_tracking'] ?? [];
$settings['auto_reply_settings'] = $settings['auto_reply_settings'] ?? ['enabled' => [], 'message' => [], 'replied_users' => []];
$settings['media_saving_settings'] = $settings['media_saving_settings'] ?? [];

$settings['reply_tracking']['1'] = $_POST['reply_tracking'] == '1';
$settings['auto_reply_settings']['enabled']['1'] = $_POST['auto_reply'] == '1';
$settings['auto_reply_settings']['message']['1'] = $_POST['auto_reply_message'];
$settings['media_saving_settings']['1'] = $_POST['media_saving'] == '1';

file_put_contents('settings.json', json_encode($settings, JSON_PRETTY_PRINT));
echo json_encode(['success' => true]);
?>