<?php
header('Content-Type: application/json');

$settings = [];
if (file_exists('settings.json')) {
    $settings = json_decode(file_get_contents('settings.json'), true);
}

echo json_encode([
    'reply_tracking' => $settings['reply_tracking']['1'] ?? false,
    'auto_reply' => $settings['auto_reply_settings']['enabled']['1'] ?? false,
    'auto_reply_message' => $settings['auto_reply_settings']['message']['1'] ?? '',
    'media_saving' => $settings['media_saving_settings']['1'] ?? false
]);
?>