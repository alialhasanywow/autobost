<?php
header('Content-Type: application/json');

$action = $_POST['action'];
$accountId = $_POST['account_id'];
$data = json_decode(file_get_contents('accounts.json'), true);

if (!isset($data[$accountId])) {
    echo json_encode(['success' => false, 'message' => 'الحساب غير موجود']);
    exit;
}

// In a real implementation, you would start/stop the bot process here
if ($action === 'start') {
    $data[$accountId]['status'] = 'active';
    file_put_contents('accounts.json', json_encode($data, JSON_PRETTY_PRINT));
    echo json_encode(['success' => true]);
} elseif ($action === 'stop') {
    $data[$accountId]['status'] = 'inactive';
    file_put_contents('accounts.json', json_encode($data, JSON_PRETTY_PRINT));
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'إجراء غير معروف']);
}
?>