<?php
header('Content-Type: application/json');

$data = json_decode(file_get_contents('accounts.json'), true);
$newAccount = [
    'name' => $_POST['name'],
    'app_id' => $_POST['app_id'],
    'api_hash' => $_POST['api_hash'],
    'phone' => $_POST['phone'],
    'status' => 'inactive'
];

$data[] = $newAccount;
file_put_contents('accounts.json', json_encode($data, JSON_PRETTY_PRINT));

// In a real implementation, you would initiate the Telegram login process here
// For demo purposes, we'll simulate requiring a verification code
echo json_encode([
    'success' => true,
    'require_code' => true,
    'account_id' => count($data) - 1,
    'message' => 'يرجى إدخال كود التحقق الذي تم إرساله إلى هاتفك'
]);
?>