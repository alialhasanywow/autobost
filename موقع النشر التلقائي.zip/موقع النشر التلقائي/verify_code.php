<?php
header('Content-Type: application/json');

// In a real implementation, you would verify the code with Telegram
// For demo purposes, we'll just accept any code
$accountId = $_POST['account_id'];
$data = json_decode(file_get_contents('accounts.json'), true);

if (isset($data[$accountId])) {
    $data[$accountId]['status'] = 'active';
    file_put_contents('accounts.json', json_encode($data, JSON_PRETTY_PRINT));
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'الحساب غير موجود']);
}
?>